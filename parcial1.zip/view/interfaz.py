import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from controllers.controller import PolinomioController


class VistaPolinomio(tk.Frame):
    def __init__(self, controller, app):
        super().__init__(app)
        self.root = app
        self.root.title("Proyecto Polinomio Matemático")
        self.root.resizable(True, True)

        self.controller = controller
        self._crear_componentes()

    def _crear_componentes(self):
        ttk.Label(self, text="<").grid(row=0, column=0)
        ttk.Label(self, text=">").grid(row=0, column=2)
        # Crear el Canvas y luego aplicar grid (no asignar el resultado de grid)
        self.marco_objeto = tk.Canvas(self, width=200, height=200)
        self.marco_objeto.grid(row=0, column=1)
        ttk.Button(self, text="Back", command=self.retroceder).grid(row=1, column=0)
        ttk.Button(self, text="Next", command=self.avanzar).grid(row=1, column=2)

    # ----- FUNCIONES -----
    def retroceder(self):
        if self.controller:
            self.controller.retroceder()

    def avanzar(self):
        if self.controller:
            self.controller.avanzar()

    def dibujar_objeto_color(self, objeto, color):
        self.marco_objeto.delete("all")
        if objeto == "Circulo":
            self.marco_objeto.create_oval(50, 50, 150, 150, fill=color)
        elif objeto == "Triangulo":
            self.marco_objeto.create_polygon(100, 50, 50, 150, 150, 150, fill=color)
        elif objeto == "Rectangulo":
            self.marco_objeto.create_rectangle(50, 50, 150, 150, fill=color)