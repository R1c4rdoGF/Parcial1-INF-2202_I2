from view.interfaz import VistaPolinomio
from controllers.controller import PolinomioController
import tkinter as tk

if __name__ == "__main__":
    app = tk.Tk()
    # crear la vista como Frame dentro de app
    vista = VistaPolinomio(None, app)
    vista.pack(expand=True, fill='both')
    # crear el controlador y asignarlo a la vista
    controller = PolinomioController(vista)
    vista.controller = controller
    app.mainloop()