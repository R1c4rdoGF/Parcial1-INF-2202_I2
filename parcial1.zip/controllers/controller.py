import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from tkinter import messagebox
from models.listaEnlazada import ListaEnlazada

class PolinomioController:
    def __init__(self, vista):
        self.Objetos = ListaEnlazada()
        self.Colores = ListaEnlazada()
        self.indice_objetos = 0
        self.indice_colores1 = 0
        self.indice_colores2 = 0
        
        self.Objetos.insert("Circulo")
        self.Objetos.insert("Triangulo")
        self.Objetos.insert("Rectangulo")

        self.Colores.insert("red")
        self.Colores.insert("green")
        self.Colores.insert("blue")

        self.vista = vista

        objeto = self.Objetos.obtenerDato(self.indice_objetos)
        color = self.Colores.obtenerDato(self.indice_colores1)
        # la vista ya tiene el método dibujar_objeto_color
        if self.vista:
            self.vista.dibujar_objeto_color(objeto, color)


    def avanzar(self):
        self.indice_objetos += 1
        if self.indice_objetos >= self.Objetos.getCant():
            self.indice_objetos = 0
            self.indice_colores2 += 1
            if self.indice_colores2 >= self.Colores.getCant():
                self.indice_colores2 = 0
            self.indice_colores1 = self.indice_colores2
        else:
            self.indice_colores1 += 1
            if self.indice_colores1 >= self.Colores.getCant():
                self.indice_colores1 = 0

        objeto = self.Objetos.obtenerDato(self.indice_objetos)
        color = self.Colores.obtenerDato(self.indice_colores1)
        # CORRECCIÓN: usar self.vista (no self.VistaPolinomio)
        if self.vista:
            self.vista.dibujar_objeto_color(objeto, color)

    def retroceder(self):
        self.indice_objetos -= 1
        if self.indice_objetos < 0:
            self.indice_objetos = self.Objetos.getCant() - 1
            self.indice_colores2 -= 1
            if self.indice_colores2 < 0:
                self.indice_colores2 = self.Colores.getCant() - 1
            self.indice_colores1 = self.indice_colores2
        else:
            self.indice_colores1 -= 1
            if self.indice_colores1 < 0:
                self.indice_colores1 = self.Colores.getCant() - 1

        objeto = self.Objetos.obtenerDato(self.indice_objetos)
        color = self.Colores.obtenerDato(self.indice_colores1)
        if self.vista:
            self.vista.dibujar_objeto_color(objeto, color)