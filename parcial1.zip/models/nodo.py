class Nodo :
    def __init__(self, data, sig=None):
        self.data = data
        self.sig = sig