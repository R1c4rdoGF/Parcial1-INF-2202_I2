from .nodo import *

class ListaEnlazada :
    def __init__(self):
        self.head = None
        self.cant = 0

    def getCant(self):
        return self.cant

    def insert(self, dato):
        nw = Nodo(dato)
        if self.head:
            aux = self.head
            while aux.sig != self.head:
                aux = aux.sig
            aux.sig = nw
            nw.sig = self.head
            self.head = nw
            self.cant += 1
        else:
            self.head = nw
            nw.sig = self.head
            self.cant += 1

    def obtenerDato(self, i):
        if self.head is None:
            print('Lista vacía')
            return None
        if i < 0 or i >= self.cant:
            print('Indice fuera de rango')
            return None
        
        act = self.head
        for x in range (i):
            act = act.sig

        return act.data

if __name__ == '__main__':
    print("hola")